v0.7.4

- Rewritten how subclasses in spells are written, so now any subclass can be added and rendered
- Fixed inability to add creatures in GM Screen's Initiative Tracker
- (Typos/Tags)
