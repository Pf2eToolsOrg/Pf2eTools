v0.7.9

- Started Lost Omens: Monsters of Myth conversion
- (Typos/Tags)
